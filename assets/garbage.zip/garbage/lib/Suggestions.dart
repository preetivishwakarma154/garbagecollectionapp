import 'dart:convert';
import 'package:garbage/http.dart' as http;

import 'package:flutter/material.dart';
import 'package:garbage/inputBox.dart';
import 'package:http/http.dart'as http;
import 'package:http/http.dart';
import 'package:http/http.dart';
class Suggestions extends StatefulWidget {
  const Suggestions({Key? key}) : super(key: key);

  @override
  State<Suggestions> createState() => _SuggestionsState();
}

class _SuggestionsState extends State<Suggestions> {

  Future<void> suggestion(

      String suggestion,
      String custid,
      ) async {
    try {
      var headers = {
        'Content-Type': 'application/json'
      };
      var request = http.Request(
          'POST', Uri.parse('http://192.168.0.105:8000/addsuggestion'));
      request.body = json.encode({
        "suggestion": _suggestion,
        'custid':336

      });
      request.headers.addAll(headers);

      http.StreamedResponse response = await request.send();

      if (response.statusCode == 200) {
        print(await response.stream.bytesToString());
      }
      else {
        print(response.reasonPhrase);
      }
    } catch (e) {
      print(e.toString());
    }
  }
  TextEditingController _suggestion = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Customer Suggestion"),
      ),
      body:  Column(
        children: [
          InputBox(controller: _suggestion, inputType: TextInputType.text, lableText: 'Write your Suggestion'),

          Container(

            margin: EdgeInsets.all(10),
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.all(10),
                  backgroundColor: Colors.blueAccent,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.all(Radius.circular(5)))),
              onPressed: () {
                // Navigator.push(
                //   context,
                //   MaterialPageRoute(builder: (context) => Login()),
                // );
                String suggest = _suggestion.text.toString();
                suggestion(_suggestion.text.toString(),"123654789");
                print(suggest);

              },
              child: Text("Submit",  style:
              TextStyle(fontWeight: FontWeight.w700, color: Colors.white,fontSize: 18),),
            ),
          ),
        ],
      ),

    );
  }
}
